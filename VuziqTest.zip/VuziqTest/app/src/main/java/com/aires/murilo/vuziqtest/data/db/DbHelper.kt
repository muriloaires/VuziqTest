package com.aires.murilo.vuziqtest.data.db

interface DbHelper {

}