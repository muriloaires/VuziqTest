package com.aires.murilo.vuziqtest.data.db.model

data class Song(var name: String, var duration: String, var mp3StreamUrl: String)