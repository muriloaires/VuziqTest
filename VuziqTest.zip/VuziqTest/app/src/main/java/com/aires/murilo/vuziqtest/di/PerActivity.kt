package com.aires.murilo.gestorproa.di

import javax.inject.Scope

/**
 * Created by Logics on 12/01/2018.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity
