package com.aires.murilo.gestorproa.di

import javax.inject.Qualifier

/**
 * Created by Logics on 12/01/2018.
 */
@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class ApplicationContext