package com.aires.murilo.vuziqtest.data.db.model

data class Album(
    var name: String, var releaseDate: Int,
    var imageUrl: String, var songs: List<Song>
) {
}