package com.aires.murilo.gestorproa.di

import javax.inject.Scope

/**
 * Created by murilo aires on 24/02/2018.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerService