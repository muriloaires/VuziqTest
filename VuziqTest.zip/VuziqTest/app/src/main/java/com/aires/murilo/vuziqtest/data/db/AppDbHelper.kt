package com.aires.murilo.vuziqtest.data.db

class AppDbHelper : DbHelper {
}