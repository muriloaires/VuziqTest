package com.aires.murilo.vuziqtest.data

import com.aires.murilo.vuziqtest.data.db.DbHelper

interface DataManager : DbHelper  {
}