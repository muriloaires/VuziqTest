package com.aires.murilo.vuziqtest.data

class AppDataManager : DataManager {
}